from django.apps import AppConfig


class StreamappConfig(AppConfig):
    name = 'streamapp'
